Thank you for purchasing DirectoryEngine PSD Template, we hope you enjoy it!

1. Introduction
This is a directory website template uniquely designed in Photoshop with a modern and futuristic look. PSD files are well organized and named accordingly so it's very easy to change any and all of the design. Template files are built in Bootstrap 1170px grid.

2. Adobe Photoshop Compatibility
These layered PSD files are compatible with Adobe CS6 and later.

3. Features
- Layered Adobe Photoshop .PSD files for a fully functional directory site
- Well organized layers makes it very easy to update
- The template design is built in Bootstrap 1170px wide
- Unique and futuristic look and feel
- A whole new place loading User Experience
- Modular UI makes the design higly customizable
- Smart Objects used for images, simply add your own images to use the design
- Use Google Fonts

3. Font used
Open Sans http://www.google.com/fonts/specimen/Open+Sans

4. Credits
Icons used in the template: Font Awesome - http://fortawesome.github.io/Font-Awesome/

5. Photos in the preview image are used for display purposes and are not included in the package.

EngineThemes - http://www.enginethemes.com
Email Address - contact@enginethemes.com
Check out DirectoryEngine WP theme here: http://www.enginethemes.com/themes/directoryengine






