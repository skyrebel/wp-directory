<?php
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

require_once "archive-listing.php";