<?php
marketengine_get_template('notices/success');
marketengine_get_template('notices/error');