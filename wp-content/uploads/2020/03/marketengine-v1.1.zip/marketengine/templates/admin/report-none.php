<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

_e("There are no results match your filter.", "enginethemes");