<div class="me-order-detail-block">
	<div class="me-row">
		<div class="me-col-md-7 me-col-sm-12">
			<div class="me-row">
				<div class="me-col-md-6 me-col-sm-6 me-col-xs-12">
					<div class="me-orderid-info">
						<h5><?php echo $transaction_label; ?></h5>
						<p><?php echo $order_number; ?></p>
					</div>
				</div>
				<div class="me-col-md-6 me-col-sm-6 me-col-xs-12">
					<div class="me-orderdate-info">
						<h5><?php echo __('Date of purchase:', 'enginethemes'); ?></h5>
						<p class="me-orderdate-info"><?php echo $payment_date; ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>