<li class="">
	<div class="me-cf-row-header">
		<div class="me-cf-row-wrap">
			<div class="me-cf-col-title"><?php _e('Field Name', 'enginethemes'); ?></div>
			<div class="me-cf-col-title"><?php _e('Field Title', 'enginethemes'); ?></div>
			<div class="me-cf-col-number"><?php _e('Number of<br/>Affected Categories', 'enginethemes'); ?></div>
		</div>
	</div>
</li>