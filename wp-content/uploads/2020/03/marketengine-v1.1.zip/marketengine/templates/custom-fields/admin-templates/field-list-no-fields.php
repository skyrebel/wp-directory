<li class="me-no-custom-fields">
<?php _e('There are no custom fields yet.', 'enginethemes'); ?>
</li>