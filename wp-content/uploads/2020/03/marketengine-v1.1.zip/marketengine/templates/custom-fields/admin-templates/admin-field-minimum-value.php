<div class="me-group-field">
	<label class="me-title"><?php _e('Minimum value', 'enginethemes'); ?> <small><?php _e('(optional)', 'enginethemes'); ?></small></label>
	<span class="me-field-control">
		<input class="me-input-field" id="field_minimum_value" type="number" name="field_minimum_value" value="<?php echo $min ?>">
	</span>
</div>