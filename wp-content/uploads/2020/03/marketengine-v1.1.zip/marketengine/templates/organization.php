<script type="application/ld+json">
  { "@context": "http://schema.org",
    "@type": "Organization",
    "name": "Fiverr",
    "url": "https://www.fiverr.com",
    "logo": "https://cdnil21.fiverrcdn.com/assets/v2_globals/fiverr-logo-new-green-9e65bddddfd33dfcf7e06fc1e51a5bc5.png",
    "sameAs": ["http://www.facebook.com/fiverr",
               "http://twitter.com/fiverr",
               "http://instagram.com/fiverr",
               "https://www.linkedin.com/company/fiverr-com",
               "http://www.pinterest.com/fiverr",
               "https://plus.google.com/+fiverr"]
  }
</script>