<div class="me-my-listing-none">
	<h3><?php _e("Currently you don't have any listing to display","enginethemes"); ?></h3>
	<p><?php printf(__("You may start posting listing <a href='%s'>here</a>","enginethemes"), marketengine_get_page_permalink('post_listing') ); ?></p>
</div>