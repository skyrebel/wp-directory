<!--Display mobile-->
<div class="me-dispute-contact-header">
    <ul class="me-dispute-contact-tabs">
        <li class="me-dispute-case-tabs">
            <span>
                <?php _e("Case Info", "enginethemes"); ?>
            </span>
        </li>
        <li class="me-dispute-action-tabs">
            <span>
                <?php _e("Action Info", "enginethemes"); ?>
            </span>
        </li>
        <li class="me-dispute-related-tabs">
            <span>
                <?php _e("Related Party &amp; Event", "enginethemes"); ?>
            </span>
        </li>
    </ul>
</div>