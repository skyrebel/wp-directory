<?php
/**
 * 	The Template for displaying list of page of listing page.
 * 	This template can be overridden by copying it to yourtheme/marketengine/listing-pagination.php.
 *
 * @author 		EngineThemes
 * @package 	MarketEngine/Templates
 * @version     1.0.0
 */
?>
<div class="me-paginations">
	<?php marketengine_paginate_link (); ?>
</div>