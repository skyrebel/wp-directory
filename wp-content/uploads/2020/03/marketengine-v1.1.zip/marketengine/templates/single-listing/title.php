<?php
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}
the_title('<h1 itemprop="name" class="listing_title entry-title">', '</h1>');