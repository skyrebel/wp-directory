<?php
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class ME_Payment {
	public function __construct() {}
	// abstract function setup_payment($order);
	// abstract function process_payment($order);
	// abstract function refund($order);
}