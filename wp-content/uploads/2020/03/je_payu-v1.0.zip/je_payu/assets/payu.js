(function($) {
    JobEngine.Views.PayuForm = JobEngine.Views.Modal_Box.extend({
        el: $('div#payu_modal'),
       	job	: [],
        events: {
            'submit form#payu_form': 'submitPayu',
            'click .modal-close' 			: 'close'
        },
        initialize: function(options) {
            JobEngine.Views.Modal_Box.prototype.initialize.apply(this, arguments);
            // bind event to modal
            //this.InitValidate();
            this.blockUi = new JobEngine.Views.BlockUi();
            // catch event select extend gateway
            //AE.pubsub.on('ae:submitPost:extendGateway', this.setupData);
            this.openpaymillModal();
            this.job	=	JobEngine.post_job.job;
                        
        },
        // callback when user select Paymill, set data and open modal
        openpaymillModal: function() {
            var job			=	JobEngine.post_job.job,
				packageID	=	job.get('job_package'),
				plans		=	JSON.parse($('#package_plans').html()),
				job_package	=	plans[packageID];
			var currency	=	je_payu.currency.icon;
            //console.log(job);
			var price		=	job_package.price + currency ;
			if($('.coupon-price').html() !== '' && $('#coupon_code').val() != '' ) price	=	$('.coupon-price').html();
			this.$el.find('span.plan_name').html( job_package.title + ' (' + price +')');
			this.$el.find('span.plan_desc').html(job_package.description);
			
			this.openModal();
            this.InitValidate();
            
        },
 		close : function (event) {
			event.preventDefault();
			this.closeModal();
		},
        InitValidate: function(){
            if(typeof this.validator_je_payu === "undefined"){
                this.validator_je_payu = $('form#payu_form').validate({
                    rules: {
                        payu_firstname: {
                            required: true,                            
                        },
                        payu_email: {
                            required: true,
                            email: true
                        },                       
                    },
                });
            }    
        },
        // catch user event click on pay
        submitPayu: function(event) {
            event.preventDefault();
            if(this.validator_je_payu.form()){
                var page_template	=	et_globals.page_template;
                var $form = $(event.currentTarget);
                var action	=	'et_payment_process'
    			if(page_template == 'page-upgrade-account.php') {
    				action	=	'resume_view_setup_payment';
    			}
                
                 var view = this;   
                    //neu muon post sang setup payment
                $.ajax({
                    type : 'post',
                    url : et_globals.ajaxURL,
                    data :{
                        action         : action,
                        payu_firstname : $form.find('#payu_firstname').val(),
                        payu_lastname  : $form.find('#payu_lastname').val(),
                        payu_email     : $form.find('#payu_email').val(),
                        payu_phone     : $form.find('#payu_phone').val(),
                        paymentType	   : 'payu',
                       	jobID		   : this.job.id,
    					authorID	   : this.job.get('author_id'),
    					packageID	   : this.job.get('job_package'),
                        coupon_code	   : $('#coupon_code').val()
                    } ,
                    beforeSend: function() {
                        view.blockUi.block('#button_payu');
                    },
                    success:function(res){
                       // view.blockUi.unblock();
                        if(res.success){
                            //return false;
                        //alert(res.data.salt);
                            $('#payu_hash').val(res.data.value.hash);
                            $('#payu_txnid').val(res.data.value.txnid);
                            $('#payu_key').val(res.data.value.key);
                            $("#payu_amount").val(res.data.value.amount);
                            $("#payu_firstname_h").val(res.data.value.firstname);
                            $("#payu_email_h").val(res.data.value.email);
                            $("#payu_phone_h").val(res.data.value.phone);
                            $("#payu_productinfo").val(res.data.value.productinfo);
                            $("#payu_hidden_form").attr("action", res.data.url);
                            $('#payu_surl').val(res.data.surl);
                            $('#payu_furl').val(res.data.furl);
                            $('#payu_curl').val(res.data.furl);
                            $('#button_payu_h').trigger("click");
                        }else{
                            pubsub.trigger('je:notification',{
    							msg	: res.msg,
    							notice_type	: 'error'
    						});
                            return false
                        }
                    }
                });
            }
        },
    });
    // init Payu form
    /*  $(document).ready(function() {
        new JobEngine.Views.PayuForm();
    });*/
	$(document).ready(function () {
    	$('#btn_payu').click(function(e){
    		e.preventDefault();
    		var payment_form	= new JobEngine.Views.PayuForm();
    		return false;
        });
	});
})(jQuery);
