(function($){
	var mobile_paymill = {
        submitPayment : function () {
            alert("1");
			var view = this;
			var page_template	=	et_globals.page_template;
			var action	=	'et_payment_process'
			if(page_template == 'page-upgrade-account.php') {
				action	=	'resume_view_setup_payment';
			}
			var packageID	= $('input[name="et_payment_package"]').val();
			console.log(packageID);
			$.ajax ({
				type : 'post',
				url  : et_globals.ajaxURL,
				data : {
				    action         : action,
                    payu_firstname : $form.find('#payu_firstname').val(),
                    payu_lastname  : $form.find('#payu_lastname').val(),
                    payu_email     : $form.find('#payu_email').val(),
                    payu_phone     : $form.find('#payu_phone').val(),
                    paymentType	   : 'payu',
                   	jobID		   : this.job.id,
					authorID	   : this.job.get('author_id'),
					packageID	   : this.job.get('job_package'),
                    coupon_code	   : $('#coupon_code').val()
				},
				beforeSend : function () {
					
					$.mobile.showPageLoadingMsg();
				},
				success : function (res) {
					
					if(res.success) {
						console.log(res);
						window.location = res.data.url;
					} else {
						alert(res.msg);
					}
					$.mobile.hidePageLoadingMsg();
					$("#submit_paymill").removeAttr('disabled');
				}
			});
		}

	};
	$(document).on('pageinit' , function () {
		$("#button_payu").click(function(){
			$("#button_payu").attr('disabled','disabled');
			$("form#payu_form").trigger("submit");
			return false;
		});

		$("form#payu_form").submit(function(event){	
            alert("a");
            var $form = $(event.currentTarget);
            var page_template	=	et_globals.page_template;
		    var action	=	'et_payment_process'
            if(page_template == 'page-upgrade-account.php') {
                action	=	'resume_view_setup_payment';
            }
    		var packageID	= $('input[name="et_payment_package"]').val();
    		console.log(packageID);
    		$.ajax ({
    			type : 'post',
    			url  : et_globals.ajaxURL,
    			data : {
    			    action         : action,
                    payu_firstname : $form.find('#payu_firstname').val(),
                    payu_lastname  : $form.find('#payu_lastname').val(),
                    payu_email     : $form.find('#payu_email').val(),
                    payu_phone     : $form.find('#payu_phone').val(),
                    paymentType	   : 'payu',
                  	jobID		: $('input[name="ad_id"]').val(),
					authorID	: $('input[name="post_author"]').val(),
					packageID	: $('input[name="et_payment_package"]').val(),
                    coupon_code	   : $('#coupon_code').val()
    			},
    			beforeSend : function () {
    				
    				$.mobile.showPageLoadingMsg();
    			},
    			success : function (res) {
    				
    				if(res.success) {
    					console.log(res);
                        $('#payu_hash').val(res.data.value.hash);
                        $('#payu_txnid').val(res.data.value.txnid);
                        $('#payu_key').val(res.data.value.key);
                        $("#payu_amount").val(res.data.value.amount);
                        $("#payu_firstname_h").val(res.data.value.firstname);
                        $("#payu_email_h").val(res.data.value.email);
                        $("#payu_phone_h").val(res.data.value.phone);
                        $("#payu_productinfo").val(res.data.value.productinfo);
                        $("#payu_hidden_form").attr("action", res.data.url);
                        $('#payu_surl').val(res.data.surl);
                        $('#payu_furl').val(res.data.furl);
                        $('#payu_curl').val(res.data.furl);
                        $('#button_payu_h').trigger("click");
    					//window.location = res.data.url;
    				} else {
    					alert(res.msg);
    				}
    				$.mobile.hidePageLoadingMsg();
    				$("#submit_paymill").removeAttr('disabled');
    			}
    		});
    	});
	});
})(jQuery);