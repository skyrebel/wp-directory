<?php

/**
 * @author Tong Quang Dat
 * @copyright 2015
 * @package JE Payment
 */

/*
Plugin Name: JE PayuMoney
Plugin URI: http://enginethemes.com/
Description: Integrates the PayuMoney payment gateway to your JE site
Version: 1.0
Author: EngineThemes
Author URI: http://enginethemes.com/
License: GPLv2
Text Domain: enginetheme
*/

require_once dirname(__FILE__) . '/update.php';

/**
 * render paymill settings form
 */
class JE_PAYU
{
	function __construct () {
		$this->add_action ();
		//register_deactivation_hook(__FILE__, array($this,'deactivation'));
	}
	private function  add_action () {
		add_action ('je_payment_settings', array ($this, 'payu_setting'));
		add_action ('after_je_payment_button', array($this, 'payu_render_button'));
		add_filter( 'et_support_payment_gateway',array($this,'et_support_payment_gateway' ));
		add_action('wp_footer' , array($this, 'frontend_js'));
		add_action('wp_head' , array($this, 'frontend_css'));
		//add_action('wp_head' , array($this, 'add_paymill_bublic_key'));
		add_filter ('et_update_payment_setting', array($this, 'payu_update_settings' ), 10 ,3);
	
		add_filter ('je_payment_setup', array($this, 'payu_setup_payment'), 10, 3);
	
		add_filter( 'je_payment_process', array($this, 'payu_process_payment'), 10 ,3 );
	
		add_filter( 'et_get_translate_string', array($this, 'add_translate_string') );
	
		add_filter ('et_enable_gateway', array($this,'et_enable_payu'), 10 , 2);

		// update for mobile version 04/04/2014
		add_action('after_je_mobile_payment_button',array($this,'add_payu_button_mobile'));
		add_action('et_mobile_head',array($this,'payu_mobile_header'));
		add_action('et_mobile_footer',array($this,'paymill_mobile_footer'));
	
	}

	function add_translate_string ($entries) {
		$pot		=	new PO();
		$pot->import_from_file(dirname(__FILE__).'/default.po',true );
		
		return	array_merge($entries, $pot->entries);
	}
	
	function frontend_css  () {
		if(is_page_template('page-post-a-job.php') || is_page_template('page-upgrade-account.php') ) {
			wp_enqueue_style( 'paymill_css',plugin_dir_url( __FILE__).'assets/payu.css' );
			$paypill			= $this->get_api();
		 	?>
		 	 <script type="text/javascript"> var PAYMILL_PUBLIC_KEY ='<?php echo $paypill["public_key"]; ?>';</script>
		 	<?php
		 }
		  
	}
	
	function frontend_js () {
	
		/*$general_opts	= new ET_GeneralOptions();
		$website_logo	= $general_opts->get_website_logo();
		$paypill		= $this->get_api();*/
	    
		if(is_page_template('page-post-a-job.php') || is_page_template('page-upgrade-account.php')) {
            wp_enqueue_script('je_payu', plugin_dir_url(__FILE__) . 'assets/payu.js', array('jquery') , '1.0', true);
							
			wp_localize_script('je_payu', 'je_payu', array(
                'currency' => ET_Payment::get_currency() ,
            )
            );
	
			include_once dirname(__FILE__).'/form-template.php';
	        
		}
	
	}
	
	/**
	 * check payment setting is enable or not
	 */
	//et_enable_gateway();

	function is_enable () {
		$payu_api	=	$this->get_api();
		
		if($payu_api['merchan_id'] == '' ) return false;
		if($payu_api['salt_key'] == '' ) return false;
		return true;
	}
	
	function et_enable_payu ($available , $gateway) {
		// echo $this->alert($gateway);
		if($gateway == 'payu') {
			if($this->is_enable ()) return true;
			return false;
		}
		return $available;
	}
    
	/**
	 * get paymill api setting
	 */
	function get_api () {
		return 	get_option( 'et_payu_api', array('merchan_id' => '', 'salt_key' => '') );
	}
    
	/**
	 * update payu api setting
	 */
	function set_api ( $api ) {
		update_option('et_payu_api', $api );
		if(!$this->is_enable()) {
			$gateways	=	ET_Payment::get_gateways();
			if(isset($gateways['payu']['active']) && $gateways['payu']['active'] != -1 ) {	 
				ET_Payment::disable_gateway('payu');
				return __('Api setting invalid', ET_DOMAIN);
			}
		}
		return true;
	}
	/**
	 * ajax callback to update payment settings
	 */
	function payu_update_settings ( $msg , $name, $value ) {
		$payu_api	=	$this->get_api();
		switch ($name) {
			case 'PAYU-MERCHAN-ID':
				$payu_api['merchan_id']	=	trim($value);
				$msg	=	$this->set_api( $payu_api );
				break;
			case 'PAYU-SALT':
				$payu_api['salt_key']	=	trim($value);
				$msg	=	$this->set_api( $payu_api );
				break;
		}
	
		return $msg;
	} 
    
    /**
     * process payment after payu return
     * @param $payment_return, $order , $payment_type
     * @return array()
     * @since 1.0
     * @package je_payment
     * @author QuangDat
     */ 
	function payu_process_payment ( $payment_return, $order , $payment_type) {

		$payu_api	= $this->get_api();		
		$apiKey         = $payu_api['salt_key'];	

		//$paymill = new Services_Paymill_Transactions( $apiKey , $apiEndpoint );
		//$trans_id = (isset($_REQUEST['trans'])) ? $_REQUEST['trans'] : '';
		//$info = $paymill->getOne($trans_id);	
		if ($payment_type == 'payu') {
            $order_data = $order -> get_order_data();
          
            if($order_data['total'] == $_REQUEST['amount']){
                $amount = $_REQUEST['amount'];
                //echo "success"."<br>";
            }
            
            $data_value = array(
                'salt' => $payu_api['salt_key'],
                'status' => $_REQUEST['status'],
                'email' => $_REQUEST['email'],
                'firstname' => $_REQUEST['firstname'],
                'productinfo' => $_REQUEST['productinfo'],
                'amount' => $amount,
                'txnid' => $_REQUEST['txnid'],
                'key' =>$payu_api['merchan_id']
            );
            
            $hash_verify = $this->ae_verify_payu_hash($data_value);
        
            if ($_REQUEST['status'] == "success" && $_REQUEST['hash'] == $hash_verify) {
                
                $payment_return = array(
                    'ACK' => true,
                    'payment' => 'payu',
                    'payment_status' => 'Completed'
                );
                $order->set_status('publish');
                $order->update_order();
            } else {
                $payment_return = array(
                    'ACK' => false,
                    'payment' => 'payu',
                    'payment_status' => 'fail',
                    'msg' => __('Payu payment method false.', ET_DOMAIN)
                );
            }
        }
    
    return $payment_return;
	}
    
    /**
     * setup payment before sent to payu
     * @param $response , $paymentType, $order
     * @return array()
     * @since 1.0
     * @package je_payment
     * @author QuangDat
     */
    function payu_setup_payment ( $response , $paymentType, $order ) {
		//$this->alert('ok');
       
        if ($paymentType == 'PAYU') {
            $payu_api	=	$this->get_api();
            
            $order_pay = $order->generate_data_to_pay();
            $order_id = $order_pay['ID'];
            //$payu_info = ae_get_option('payu');
            $productinfo = array_values($order_pay['products']);
            $test_mode = ET_Payment::get_payment_test_mode();
            $payu_url = 'https://secure.payu.in/_payment';
            if ($test_mode) {
                $payu_url = 'https://test.payu.in/_payment';
            }
            
            $hash_data['key'] = $payu_api['merchan_id'];
            $hash_data['txnid'] = substr(hash('sha256', mt_rand() . microtime()) , 0, 20);
             // Unique alphanumeric Transaction ID
            $hash_data['amount'] = $productinfo[0]['AMT'];
            $hash_data['productinfo'] = $productinfo[0]['NAME'];
            $hash_data['firstname'] = $_POST['payu_firstname'];
            $hash_data['email'] = $_POST['payu_email'];
            $hash_data['phone'] = $_POST['payu_phone'];
            $hash_data['hash'] = $this->ae_calculate_hash_before_transaction($hash_data);
           
            //$response = json_encode($hash_data);
            if ($hash_data['email'] != "" && $hash_data['firstname'] != "") {
                $response = array(
                    'success' => true,
                    'data' => array(
                        'url' => $payu_url,
                        'ACK' => true,
                        'value' => $hash_data, 
                        'surl' => et_get_page_link('process-payment', array(
                            'paymentType' => 'payu'
                        )) ,
                        'furl' => et_get_page_link('process-payment', array(
                            'paymentType' => 'payu'
                        )) ,
                    ) ,
                    'paymentType' => 'PAYU'
                );
            } else {
                $response = array(
                    'success' => false,
                    'data' => array(
                        'url' => site_url('post-place') ,
                        'ACK' => false
                    )
                );
            }
        }
    return $response;
	}
    
	/**
	 * render paymill checkout button
	 */
	function payu_render_button ($payment_gateways) {
		if(!isset($payment_gateways['payu']))  return;
		$stripe	=	$payment_gateways['payu'];
		if( !isset($stripe['active']) || $stripe['active'] == -1) return ;
		?>
			<li class="clearfix">
				<div class="f-left">
					<div class="title"><?php _e( 'PayU Money', ET_DOMAIN )?></div>
					<div class="desc"><?php _e( 'Pay using your credit card through Payu Money.', ET_DOMAIN )?></div>
				</div>
				<div class="btn-select f-right">
					<button id="btn_payu" class="bg-btn-hyperlink border-radius" data-gateway="paymill" ><?php _e('Select', ET_DOMAIN );?></button>
				</div>
			</li>
		<?php
	}

	function add_payu_button_mobile($payment_gateways){
		if(!isset($payment_gateways['payu']))  return;
		$paymill	=	$payment_gateways['payu'];
		if( !isset($paymill['active']) || $paymill['active'] == -1) return ;
		?>
		<style type="text/css">
			.post-new-classified{
				padding: 20px 15px;
			}
					.post-new-classified.paymill a {
						background: -moz-linear-gradient(center top , #FEFEFE 0%, #FAFAFA 16%, #F0F0F0 85%, #E0E0E0 100%) repeat scroll 0 0 rgba(0, 0, 0, 0);
						border: 1px solid #BABABA;
						box-shadow: 1px 0 1px 0 #E3E3E3;
						color: #777777 !important;
						text-align: center;
						text-shadow: 0 -1px 0 #EFEFEF !important;

						display: block;
						clear: both;
						overflow: hidden;						
						font-size: 16px;
						min-width: 0.75em;
						overflow: hidden;
						padding: 0.9em 20px;
						position: relative;
						text-overflow: ellipsis;
						white-space: nowrap;
						font-weight: bold;
						text-decoration: none;
						margin: 10px 0 0 0;
					}
		</style>	
		<div data-role="fieldcontain" class="post-new-classified paymill" >
			
			<?php _e( 'Pay using your credit card through Payu.', ET_DOMAIN )?>
			<a href="#payu-modal" data-rel="popup" data-position-to="window" class="ui-btn ui-corner-all ui-shadow ui-btn-inline" >
				<?php _e( 'Payu', ET_DOMAIN ); ?>
			</a>
		</div>
		
		<div data-role="popup" id="payu-modal">
				<?php include_once dirname(__FILE__).'/form-template.php'; ?>
			</div>
		<?php
	}
	function payu_mobile_header(){
		
		$payu		= $this->get_api();
	    $currency 	= ET_Payment::get_currency() ;
		if(is_page_template('page-post-a-job.php') || is_page_template('page-upgrade-account.php')) { ?>
			
			<script type="text/javascript">
			var  je_paymill = {
					'currency'	 	: {<?php foreach($currency as $key=>$value){ echo '"'.$key.'":"'.$value.'",';}?>},
				}
			
			</script>
			<?php		
	        
		}

	}
	function paymill_mobile_footer(){
		if(is_page_template('page-post-a-job.php') || is_page_template('page-upgrade-account.php')) { 
			?>
			<script type="text/javascript" src="<?php echo plugin_dir_url( __FILE__).'assets/je_payu_mobile.js';?>"></script>
			<?php 
		}
	}
	function ae_verify_payu_hash($data_value) {
        
        extract($data_value);
        
        $retHashSeq = $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        
        $hash = strtolower(hash("sha512", $retHashSeq));
        return $hash;
    }
    
    /**
     * hash data 
     * @param mix
     * @return $hashdata
     * @since 1.0
     * @author QuangDat
     */
    function ae_calculate_hash_before_transaction($hash_data) {
        $payu_api	=	$this->get_api();
        $hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
        $hashVarsSeq = explode('|', $hashSequence);
        $hash_string = '';
        foreach ($hashVarsSeq as $hash_var) {
            $hash_string.= isset($hash_data[$hash_var]) ? $hash_data[$hash_var] : '';
            $hash_string.= '|';
        }
        
        $hash_string.= $payu_api ['salt_key'];
        
        $hash = strtolower(hash('sha512', $hash_string));
        return $hash;
        //return  $payu_api ['payu_salt'];  
        
    }
    
	// add stripe to je support payment
	function et_support_payment_gateway ( $gateway ) {
		$gateway['payu']	=	array (
									'label' 		=> __("PayU",ET_DOMAIN),  
									'description'	=> __("Send your payment through paymill", ET_DOMAIN),
									'active' 		=> -1
									);
		return $gateway;
	}
	/**
	 * render payu settings form in backend
	*/
	function payu_setting () {
		$payu_api = $this->get_api();
		//print_r($payu_api);
		?>
			<div class="item">
				<div class="payment">
					<a class="icon" data-icon="y" href="#"></a>
					<div class="button-enable font-quicksand">
						<?php et_display_enable_disable_button('payu', 'Payu')?>
					</div>
					<span class="message"></span>
					<?php _e("Payu",ET_DOMAIN);?>
				</div>
				<div class="form payment-setting">
					<div class="form-item">
						<div class="label">
							<?php _e("Merchant ID PayuMoney ",ET_DOMAIN);?> 
						</div>
						<input class="bg-grey-input <?php if($payu_api['merchan_id'] == '') echo 'color-error' ?>" name="payu-merchan-id" type="text" value="<?php echo $payu_api['merchan_id']  ?> " />
						<span class="icon <?php if($payu_api['merchan_id'] == '') echo 'color-error' ?>" data-icon="<?php  data_icon($payu_api['merchan_id']) ?>"></span>
					</div>
					<div class="form-item">
						<div class="label">
							<?php _e("Salt Key PayuMoney",ET_DOMAIN);?>
							
						</div>
						<input class="bg-grey-input <?php if($payu_api['salt_key'] == '') echo 'color-error' ?>" type="text" name="payu-salt" value="<?php echo $payu_api['salt_key'] ?> " />
						<span class="icon <?php if($payu_api['salt_key'] == '') echo 'color-error' ?>" data-icon="<?php  data_icon($payu_api['salt_key']) ?>"></span>
					</div>
				</div>
			</div>
		<?php 
	}
	
}

new JE_PAYU();


